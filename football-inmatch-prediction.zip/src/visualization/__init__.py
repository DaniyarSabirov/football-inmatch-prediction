"""Reusable research visualizations."""
