"""Shared project utilities."""
